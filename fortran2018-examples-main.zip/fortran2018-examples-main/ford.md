src_dir: ./
output_dir: ./docs
project: Fortran 2018 examples
project_github: https://github.com/scivision/fortran2018-examples
project_website: https://scivision.github.io/fortran2018-examples
summary: Fortran 2008 / 2018 examples
author: Michael Hirsch Ph.D.
author_description: SciVision, Inc.
github: https://github.com/scivision
license: by
exclude: CMakeFortranCompilerId.F
display: public
         protected
         private
source: false
graph: true
search: true
