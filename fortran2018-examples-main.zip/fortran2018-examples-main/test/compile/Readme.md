# This directory covers build system quirks
