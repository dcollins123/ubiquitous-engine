# Fortran 2008 submodule examples

See [fortran-submodule](https://github.com/scivision/fortran-submodule) for many more examples.

The examples "explicit.f90" and "procedure.f90" are for an [NVIDIA HPC nvfortran bug](https://forums.developer.nvidia.com/t/fortran-2008-submodule-select-type-bug/231252)
