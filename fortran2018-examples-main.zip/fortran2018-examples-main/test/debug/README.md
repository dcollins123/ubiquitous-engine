# Debug examples

Note: typecast.f90 was removed because it was invalid Fortran.

```fortran
logical :: x=1
```

is not valid Fortran and should not be used.
